package edu.mit.csail.sdg.alloy4whole;


public class Alloy {

    public static void main(String args[]) throws Exception {
        SimpleGUI.main(args);
    }
}
