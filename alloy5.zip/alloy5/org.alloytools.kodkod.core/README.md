# kodkod-star

Kodkod with arithmetic overflow prevention and higher-order solving extensions
